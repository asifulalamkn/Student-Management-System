package model;

public class Student {
    private int id;
    private String name;
    private String department;
    private double cgpa;

    public Student(int id, String name, String department, double cgpa) {
        this.id = id;
        this.name = name;
        this.department = department;
        this.cgpa = cgpa;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    public double getCgpa() { return cgpa; }
    public void setCgpa(double cgpa) { this.cgpa = cgpa; }

    @Override
    public String toString() {
        return String.format("ID: %d | Name: %s | Dept: %s | CGPA: %.2f",
                id, name, department, cgpa);
    }

    public String toCSV() {
        return id + "," + name.replace(",", " ") + "," + department.replace(",", " ") + "," + cgpa;
    }

    public static Student fromCSV(String line) {
        if (line == null || line.trim().isEmpty()) return null;
        String[] parts = line.split(",", -1);
        if (parts.length < 4) return null;
        try {
            int id = Integer.parseInt(parts[0].trim());
            String name = parts[1].trim();
            String dept = parts[2].trim();
            double cgpa = Double.parseDouble(parts[3].trim());
            return new Student(id, name, dept, cgpa);
        } catch (Exception e) {
            return null;
        }
    }
}
