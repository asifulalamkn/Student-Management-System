import model.Student;
import service.StudentManager;

import java.util.List;
import java.util.Scanner;
import java.util.Optional;

public class Main {
    private static StudentManager manager = new StudentManager();
    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("=== Student Management System ===");
        boolean running = true;
        while (running) {
            printMenu();
            System.out.print("Choose: ");
            String choice = sc.nextLine().trim();
            switch (choice) {
                case "1" -> addStudent();
                case "2" -> showAll();
                case "3" -> searchById();
                case "4" -> searchByName();
                case "5" -> updateStudent();
                case "6" -> deleteStudent();
                case "7" -> {
                    System.out.println("Exiting... Goodbye!");
                    running = false;
                }
                default -> System.out.println("Invalid option. Try again.");
            }
        }
    }

    private static void printMenu() {
        System.out.println("\n1. Add Student");
        System.out.println("2. Show All Students");
        System.out.println("3. Search by ID");
        System.out.println("4. Search by Name");
        System.out.println("5. Update Student");
        System.out.println("6. Delete Student");
        System.out.println("7. Exit");
    }

    private static void addStudent() {
        try {
            System.out.print("Enter ID (integer): ");
            int id = Integer.parseInt(sc.nextLine().trim());
            System.out.print("Enter name: ");
            String name = sc.nextLine().trim();
            System.out.print("Enter department: ");
            String dept = sc.nextLine().trim();
            System.out.print("Enter CGPA: ");
            double cgpa = Double.parseDouble(sc.nextLine().trim());

            Student s = new Student(id, name, dept, cgpa);
            if (manager.addStudent(s)) System.out.println("Student added.");
            else System.out.println("Student with this ID already exists.");
        } catch (Exception e) {
            System.out.println("Invalid input. Operation cancelled.");
        }
    }

    private static void showAll() {
        List<Student> all = manager.getAll();
        if (all.isEmpty()) System.out.println("No students found.");
        else all.forEach(System.out::println);
    }

    private static void searchById() {
        try {
            System.out.print("Enter ID: ");
            int id = Integer.parseInt(sc.nextLine().trim());
            Optional<Student> opt = manager.findById(id);
            if (opt.isPresent()) System.out.println(opt.get());
            else System.out.println("Not found.");
        } catch (Exception e) {
            System.out.println("Invalid ID.");
        }
    }

    private static void searchByName() {
        System.out.print("Enter name or part: ");
        String name = sc.nextLine().trim();
        List<Student> list = manager.findByName(name);
        if (list.isEmpty()) System.out.println("No match.");
        else list.forForEach(System.out::println);
    }

    private static void updateStudent() {
        try {
            System.out.print("Enter ID to update: ");
            int id = Integer.parseInt(sc.nextLine().trim());
            System.out.print("New name (leave blank to keep): ");
            String name = sc.nextLine();
            System.out.print("New department (leave blank to keep): ");
            String dept = sc.nextLine();
            System.out.print("New CGPA (leave blank to keep): ");
            String cgpaStr = sc.nextLine();
            Double cgpa = cgpaStr.isBlank() ? null : Double.parseDouble(cgpaStr);
            if (manager.updateStudent(id, name, dept, cgpa)) System.out.println("Updated.");
            else System.out.println("Student not found.");
        } catch (Exception e) {
            System.out.println("Invalid input.");
        }
    }

    private static void deleteStudent() {
        try {
            System.out.print("Enter ID to delete: ");
            int id = Integer.parseInt(sc.nextLine().trim());
            if (manager.deleteStudent(id)) System.out.println("Deleted.");
            else System.out.println("Student not found.");
        } catch (Exception e) {
            System.out.println("Invalid input.");
        }
    }
}
