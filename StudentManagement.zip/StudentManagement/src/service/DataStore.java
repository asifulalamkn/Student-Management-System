package service;

import model.Student;

import java.io.*;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;

public class DataStore {
    private static final String DATA_DIR = "data";
    private static final String FILE = DATA_DIR + File.separator + "students.csv";

    public DataStore() {
        try {
            Path dir = Paths.get(DATA_DIR);
            if (!Files.exists(dir)) Files.createDirectories(dir);
            Path file = Paths.get(FILE);
            if (!Files.exists(file)) Files.createFile(file);
        } catch (IOException e) {
            System.out.println("Error initializing data store: " + e.getMessage());
        }
    }

    public List<Student> loadAll() {
        List<Student> list = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                Student s = Student.fromCSV(line);
                if (s != null) list.add(s);
            }
        } catch (IOException e) {
        }
        return list;
    }

    public void saveAll(List<Student> students) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE))) {
            for (Student s : students) {
                bw.write(s.toCSV());
                bw.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving data: " + e.getMessage());
        }
    }
}
