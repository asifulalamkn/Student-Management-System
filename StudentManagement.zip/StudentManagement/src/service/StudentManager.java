package service;

import model.Student;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class StudentManager {
    private List<Student> students;
    private DataStore store;

    public StudentManager() {
        store = new DataStore();
        students = store.loadAll();
    }

    public List<Student> getAll() {
        return new ArrayList<>(students);
    }

    public boolean addStudent(Student s) {
        if (findById(s.getId()).isPresent()) return false;
        students.add(s);
        store.saveAll(students);
        return true;
    }

    public Optional<Student> findById(int id) {
        return students.stream().filter(st -> st.getId() == id).findFirst();
    }

    public List<Student> findByName(String name) {
        List<Student> res = new ArrayList<>();
        for (Student s : students) {
            if (s.getName().toLowerCase().contains(name.toLowerCase())) res.add(s);
        }
        return res;
    }

    public boolean updateStudent(int id, String name, String dept, Double cgpa) {
        Optional<Student> opt = findById(id);
        if (opt.isEmpty()) return false;
        Student s = opt.get();
        if (name != null && !name.isBlank()) s.setName(name);
        if (dept != null && !dept.isBlank()) s.setDepartment(dept);
        if (cgpa != null) s.setCgpa(cgpa);
        store.saveAll(students);
        return true;
    }

    public boolean deleteStudent(int id) {
        Optional<Student> opt = findById(id);
        if (opt.isEmpty()) return false;
        students.remove(opt.get());
        store.saveAll(students);
        return true;
    }
}
